# Unitree G1 VLM Planner Benchmark — Implementation Kit

**This is an implementation specification plus dry-run contract-validation and metric-summary examples — not a deployed robotics controller and not a completed experimental result.** It issues **no commands to any real robot**.

## Files

- `blueprint.md`: full engineering plan, model and controller compatibility caveats, task design, metrics and experiments.
- `configs/model_registry.json`: four candidate planner IDs and endpoint placeholders; pin model revisions before experiments.
- `configs/benchmark_matrix.json`: proposed pilot and held-out task matrix, not measured outcomes.
- `schemas/planner_request.schema.json`, `schemas/planner_response.schema.json`: common data exchange.
- `examples/request_tidy.json`, `examples/response_inspect.json`, `examples/response_hallucination.json`: positive and negative data fixtures.
- `tools/validate_plan.py`: a read-only JSON-schema and semantic identifier validator. **Not an operational safety validator.**
- `tools/summarize_logs.py`: diagnostic metrics aggregation; no confidence intervals or pairwise tests implemented.
- `examples/sample_episode_metrics.jsonl`: **entirely synthetic illustrative records** — not results from real models, controllers or Isaac Sim.
- `tests/test_contract.py`: test contract behavior.

## Quick dry-run (Python 3.10+)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python tools/validate_plan.py examples/request_tidy.json examples/response_inspect.json
python tools/validate_plan.py examples/request_tidy.json examples/response_hallucination.json  # expected INVALID, exit 1
python tools/summarize_logs.py examples/sample_episode_metrics.jsonl
python -m unittest discover -s tests -v
```

## Before any G1 actuator is connected

1. Choose exact Unitree G1 joint/hand embodiment and local safety supervisor.
2. Qualify N1.7+SONIC VLA and G1 locomotion independently on the identical rig.
3. Replace mocked/illustrative requests and event logs with signed, timestamped observations from a trusted perception bridge.
4. Add dynamic obstacle, collision, map-frame, robot state, camera-sync, stand/sit and watchdog safety gates. The included validator does **not** check those conditions.
5. Separate public robot-facing observations from simulator ground-truth scoring data; never leak GT to a planner.
6. Implement 4 real model-serving clients with retries, rate limits, exact revision pinning, API privacy and spending controls.
7. Freeze all execution-layer versions before comparing the four planners.

See `blueprint.md` for the benchmark protocol and authoritative public source links.
