"""Reference read-only validator. It does not send robot commands."""
import argparse
import json
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = json.loads((ROOT / "schemas/planner_response.schema.json").read_text())
REQUEST_SCHEMA = json.loads((ROOT / "schemas/planner_request.schema.json").read_text())


def validate(request: dict, response: dict) -> list[str]:
    errors = []
    for obj, schema, kind in [(request, REQUEST_SCHEMA, "request"), (response, SCHEMA, "response")]:
        for e in Draft202012Validator(schema).iter_errors(obj):
            errors.append(f"{kind}: {e.message}")
    if errors:
        return errors
    if request["mission_id"] != response["mission_id"] or request["decision_id"] != response["decision_id"]:
        errors.append("mission/decision mismatch — reject potential replay or stale response")
    if response["decision"] != "ACT":
        return errors
    step = response["step"]
    skill = step["skill"]
    target = step["target_id"]
    if skill not in request["skills"]:
        errors.append(f"skill not advertised: {skill}")
    objects = {o["id"] for o in request["objects"]}
    locations = set(request["map"]["locations"])
    allowed = set(request["constraints"]["authorized_locations"])
    denied = set(request["constraints"]["must_not_enter"])
    if skill == "navigate_to":
        if target not in (locations & allowed) or target in denied:
            errors.append(f"navigation target not in authorized known locations: {target}")
        # This validates semantics only: route availability requires a trusted map service.
    if skill in {"pick", "place"} and target not in objects:
        errors.append(f"object ID not observed: {target}")
    if skill in {"inspect_scene", "verify"} and target is not None and target not in objects | locations:
        errors.append(f"inspect/verify target unknown: {target}")
    if skill == "pick" and request["robot"]["holding"]:
        errors.append("pick with occupied hands; check preconditions")
    if skill == "place":
        if target not in request["robot"]["holding"]:
            errors.append(f"place requires observed held object: {target}")
        dest = step["params"].get("destination_id")
        if dest not in (locations & allowed) or dest in denied:
            errors.append(f"placement location unknown/not authorized: {dest}")
    if skill in {"pick", "place"} and not request["robot"]["balance_ok"]:
        errors.append("manipulation while balance is not OK")
    if skill == "abort" and response["decision"] != "ABORT":
        errors.append("abort must use the ABORT decision, not ACT")
    return errors


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("request", type=Path)
    parser.add_argument("response", type=Path)
    args = parser.parse_args()
    errors = validate(json.loads(args.request.read_text()), json.loads(args.response.read_text()))
    print("VALID (contract-level; no physics or safety clearance)" if not errors else "INVALID\n" + "\n".join(errors))
    raise SystemExit(1 if errors else 0)

if __name__ == "__main__":
    main()
