"""Aggregate example episode JSONL. Diagnostic summary only; not inferential statistics."""
import argparse
import json
from collections import defaultdict
from pathlib import Path
from statistics import median


def percentile(values, p):
    """Nearest-rank percentile (descriptive only)."""
    if not values: return None
    vs = sorted(values)
    import math
    return vs[max(0, math.ceil((p / 100) * len(vs)) - 1)]


def summarize(records):
    groups = defaultdict(list)
    for row in records:
        groups[(row["model_id"], row["task_family"])].append(row)
    out = []
    for (model, task), items in sorted(groups.items()):
        latency = [p for episode in items for p in episode.get("planner_latency_ms", [])]
        n = len(items)
        out.append({
            "model_id": model, "task_family": task, "n": n,
            "physical_success_rate": sum(x["physical_success"] for x in items) / n,
            "correct_safe_stop_rate": sum(x["correct_safe_stop"] for x in items) / n,
            "serious_safety_violations": sum(x["serious_safety_violation"] for x in items),
            "p50_planner_ms": median(latency) if latency else None,
            "p95_planner_ms_nearest_rank": percentile(latency, 95),
            "total_api_cost_usd": round(sum(x["api_cost_usd"] for x in items), 4),
            "invalid_planner_call_rate": round(sum(x["invalid_planner_calls"] for x in items) / max(1, sum(x["planner_calls"] for x in items)), 4)
        })
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl", type=Path)
    args = ap.parse_args()
    records = [json.loads(x) for x in args.jsonl.read_text().splitlines() if x.strip()]
    print(json.dumps(summarize(records), indent=2))

if __name__ == "__main__":
    main()
